To run the game:
1) Open a command prompt and run the Game Manager
2)Open a second a command prompt and run MainMenu
 Note: you need to maximize it
3) Type localhost in IP box and 31415 in port box.
4) This leads to the setup frame, where the player place the ships on the grid with the left mouse button. 
5) So, after the players placed their ship, the game suppose to transite to the gameplay frame. There are two screens, where the top grid is where the player choose to attack,
 the bottom grid shows their ships and the areas that the opponent attacked